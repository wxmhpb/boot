package com.bootdo.wuliao.domain;

public class WuliaoshangliaoshunxubiaoDO {
    private String luci;
    private Integer liaocanghao1;
    //材料1名称
    private String cl1mingcheng;
    //材料1数量
    private Float cl1shengyuliang;
    //材料2名称
    private Integer liaocanghao2;
    private String cl2mingcheng;
    //材料2数量
    private Float cl2shengyuliang;
    //材料3名称
    private Integer liaocanghao3;
    private String cl3mingcheng;
    //材料3数量
    private Float cl3shengyuliang;
    //材料4名称
    private Integer liaocanghao4;
    private String cl4mingcheng;
    //材料4数量
    private Float cl4shengyuliang;
    //材料5名称
    private Integer liaocanghao5;
    private String cl5mingcheng;
    //材料5数量
    private Float cl5shengyuliang;
    //材料6名称
    private Integer liaocanghao6;
    private String cl6mingcheng;
    //材料6数量
    private Float cl6shengyuliang;
    //材料7名称
    private Integer liaocanghao7;
    private String cl7mingcheng;
    //材料7数量
    private Float cl7shengyuliang;
    //材料8名称
    private Integer liaocanghao8;
    private String cl8mingcheng;
    //材料8数量
    private Float cl8shengyuliang;
    //材料9名称
    private Integer liaocanghao9;
    private String cl9mingcheng;
    //材料9数量
    private Float cl9shengyuliang;
    //材料10名称
    private Integer liaocanghao10;
    private String cl10mingcheng;
    //材料10数量
    private Float cl10shengyuliang;
    //材料11名称
    private Integer liaocanghao11;
    private String cl11mingcheng;
    //材料11数量
    private Float cl11shengyuliang;
    //材料12名称
    private Integer liaocanghao12;
    private String cl12mingcheng;
    //材料12数量
    private Float cl12shengyuliang;
    //材料13名称
    private Integer liaocanghao13;
    private String cl13mingcheng;
    //材料13数量
    private Float cl13shengyuliang;
    //材料14名称
    private Integer liaocanghao14;
    private String cl14mingcheng;
    //材料14数量
    private Float cl14shengyuliang;
    //材料15名称
    private Integer liaocanghao15;
    private String cl15mingcheng;
    //材料15数量
    private Float cl15shengyuliang;
    //材料16名称
    private Integer liaocanghao16;
    private String cl16mingcheng;
    //材料16数量
    private Float cl16shengyuliang;
    //材料17名称
    private Integer liaocanghao17;
    private String cl17mingcheng;
    //材料17数量
    private Float cl17shengyuliang;
    //材料18名称
    private Integer liaocanghao18;
    private String cl18mingcheng;
    //材料18数量
    private Float cl18shengyuliang;
    //材料19名称
    private Integer liaocanghao19;
    private String cl19mingcheng;
    //材料19数量
    private Float cl19shengyuliang;
    //材料20名称
    private Integer liaocanghao20;
    private String cl20mingcheng;
    //材料20数量
    private Float cl20shengyuliang;

    public String getLuci() {
        return luci;
    }

    public void setLuci(String luci) {
        this.luci = luci;
    }

    public Integer getLiaocanghao1() {
        return liaocanghao1;
    }

    public void setLiaocanghao1(Integer liaocanghao1) {
        this.liaocanghao1 = liaocanghao1;
    }

    public Integer getLiaocanghao2() {
        return liaocanghao2;
    }

    public void setLiaocanghao2(Integer liaocanghao2) {
        this.liaocanghao2 = liaocanghao2;
    }

    public Integer getLiaocanghao3() {
        return liaocanghao3;
    }

    public void setLiaocanghao3(Integer liaocanghao3) {
        this.liaocanghao3 = liaocanghao3;
    }

    public Integer getLiaocanghao4() {
        return liaocanghao4;
    }

    public void setLiaocanghao4(Integer liaocanghao4) {
        this.liaocanghao4 = liaocanghao4;
    }

    public Integer getLiaocanghao5() {
        return liaocanghao5;
    }

    public void setLiaocanghao5(Integer liaocanghao5) {
        this.liaocanghao5 = liaocanghao5;
    }

    public Integer getLiaocanghao6() {
        return liaocanghao6;
    }

    public void setLiaocanghao6(Integer liaocanghao6) {
        this.liaocanghao6 = liaocanghao6;
    }

    public Integer getLiaocanghao7() {
        return liaocanghao7;
    }

    public void setLiaocanghao7(Integer liaocanghao7) {
        this.liaocanghao7 = liaocanghao7;
    }

    public Integer getLiaocanghao8() {
        return liaocanghao8;
    }

    public void setLiaocanghao8(Integer liaocanghao8) {
        this.liaocanghao8 = liaocanghao8;
    }

    public Integer getLiaocanghao9() {
        return liaocanghao9;
    }

    public void setLiaocanghao9(Integer liaocanghao9) {
        this.liaocanghao9 = liaocanghao9;
    }

    public Integer getLiaocanghao10() {
        return liaocanghao10;
    }

    public void setLiaocanghao10(Integer liaocanghao10) {
        this.liaocanghao10 = liaocanghao10;
    }

    public Integer getLiaocanghao11() {
        return liaocanghao11;
    }

    public void setLiaocanghao11(Integer liaocanghao11) {
        this.liaocanghao11 = liaocanghao11;
    }

    public Integer getLiaocanghao12() {
        return liaocanghao12;
    }

    public void setLiaocanghao12(Integer liaocanghao12) {
        this.liaocanghao12 = liaocanghao12;
    }

    public Integer getLiaocanghao13() {
        return liaocanghao13;
    }

    public void setLiaocanghao13(Integer liaocanghao13) {
        this.liaocanghao13 = liaocanghao13;
    }

    public Integer getLiaocanghao14() {
        return liaocanghao14;
    }

    public void setLiaocanghao14(Integer liaocanghao14) {
        this.liaocanghao14 = liaocanghao14;
    }

    public Integer getLiaocanghao15() {
        return liaocanghao15;
    }

    public void setLiaocanghao15(Integer liaocanghao15) {
        this.liaocanghao15 = liaocanghao15;
    }

    public Integer getLiaocanghao16() {
        return liaocanghao16;
    }

    public void setLiaocanghao16(Integer liaocanghao16) {
        this.liaocanghao16 = liaocanghao16;
    }

    public Integer getLiaocanghao17() {
        return liaocanghao17;
    }

    public void setLiaocanghao17(Integer liaocanghao17) {
        this.liaocanghao17 = liaocanghao17;
    }

    public Integer getLiaocanghao18() {
        return liaocanghao18;
    }

    public void setLiaocanghao18(Integer liaocanghao18) {
        this.liaocanghao18 = liaocanghao18;
    }

    public Integer getLiaocanghao19() {
        return liaocanghao19;
    }

    public void setLiaocanghao19(Integer liaocanghao19) {
        this.liaocanghao19 = liaocanghao19;
    }

    public Integer getLiaocanghao20() {
        return liaocanghao20;
    }

    public void setLiaocanghao20(Integer liaocanghao20) {
        this.liaocanghao20 = liaocanghao20;
    }

    public String getCl1mingcheng() {
        return cl1mingcheng;
    }

    public void setCl1mingcheng(String cl1mingcheng) {
        this.cl1mingcheng = cl1mingcheng;
    }

    public Float getCl1shengyuliang() {
        return cl1shengyuliang;
    }

    public void setCl1shengyuliang(Float cl1shengyuliang) {
        this.cl1shengyuliang = cl1shengyuliang;
    }

    public String getCl2mingcheng() {
        return cl2mingcheng;
    }

    public void setCl2mingcheng(String cl2mingcheng) {
        this.cl2mingcheng = cl2mingcheng;
    }

    public Float getCl2shengyuliang() {
        return cl2shengyuliang;
    }

    public void setCl2shengyuliang(Float cl2shengyuliang) {
        this.cl2shengyuliang = cl2shengyuliang;
    }

    public String getCl3mingcheng() {
        return cl3mingcheng;
    }

    public void setCl3mingcheng(String cl3mingcheng) {
        this.cl3mingcheng = cl3mingcheng;
    }

    public Float getCl3shengyuliang() {
        return cl3shengyuliang;
    }

    public void setCl3shengyuliang(Float cl3shengyuliang) {
        this.cl3shengyuliang = cl3shengyuliang;
    }

    public String getCl4mingcheng() {
        return cl4mingcheng;
    }

    public void setCl4mingcheng(String cl4mingcheng) {
        this.cl4mingcheng = cl4mingcheng;
    }

    public Float getCl4shengyuliang() {
        return cl4shengyuliang;
    }

    public void setCl4shengyuliang(Float cl4shengyuliang) {
        this.cl4shengyuliang = cl4shengyuliang;
    }

    public String getCl5mingcheng() {
        return cl5mingcheng;
    }

    public void setCl5mingcheng(String cl5mingcheng) {
        this.cl5mingcheng = cl5mingcheng;
    }

    public Float getCl5shengyuliang() {
        return cl5shengyuliang;
    }

    public void setCl5shengyuliang(Float cl5shengyuliang) {
        this.cl5shengyuliang = cl5shengyuliang;
    }

    public String getCl6mingcheng() {
        return cl6mingcheng;
    }

    public void setCl6mingcheng(String cl6mingcheng) {
        this.cl6mingcheng = cl6mingcheng;
    }

    public Float getCl6shengyuliang() {
        return cl6shengyuliang;
    }

    public void setCl6shengyuliang(Float cl6shengyuliang) {
        this.cl6shengyuliang = cl6shengyuliang;
    }

    public String getCl7mingcheng() {
        return cl7mingcheng;
    }

    public void setCl7mingcheng(String cl7mingcheng) {
        this.cl7mingcheng = cl7mingcheng;
    }

    public Float getCl7shengyuliang() {
        return cl7shengyuliang;
    }

    public void setCl7shengyuliang(Float cl7shengyuliang) {
        this.cl7shengyuliang = cl7shengyuliang;
    }

    public String getCl8mingcheng() {
        return cl8mingcheng;
    }

    public void setCl8mingcheng(String cl8mingcheng) {
        this.cl8mingcheng = cl8mingcheng;
    }

    public Float getCl8shengyuliang() {
        return cl8shengyuliang;
    }

    public void setCl8shengyuliang(Float cl8shengyuliang) {
        this.cl8shengyuliang = cl8shengyuliang;
    }

    public String getCl9mingcheng() {
        return cl9mingcheng;
    }

    public void setCl9mingcheng(String cl9mingcheng) {
        this.cl9mingcheng = cl9mingcheng;
    }

    public Float getCl9shengyuliang() {
        return cl9shengyuliang;
    }

    public void setCl9shengyuliang(Float cl9shengyuliang) {
        this.cl9shengyuliang = cl9shengyuliang;
    }

    public String getCl10mingcheng() {
        return cl10mingcheng;
    }

    public void setCl10mingcheng(String cl10mingcheng) {
        this.cl10mingcheng = cl10mingcheng;
    }

    public Float getCl10shengyuliang() {
        return cl10shengyuliang;
    }

    public void setCl10shengyuliang(Float cl10shengyuliang) {
        this.cl10shengyuliang = cl10shengyuliang;
    }

    public String getCl11mingcheng() {
        return cl11mingcheng;
    }

    public void setCl11mingcheng(String cl11mingcheng) {
        this.cl11mingcheng = cl11mingcheng;
    }

    public Float getCl11shengyuliang() {
        return cl11shengyuliang;
    }

    public void setCl11shengyuliang(Float cl11shengyuliang) {
        this.cl11shengyuliang = cl11shengyuliang;
    }

    public String getCl12mingcheng() {
        return cl12mingcheng;
    }

    public void setCl12mingcheng(String cl12mingcheng) {
        this.cl12mingcheng = cl12mingcheng;
    }

    public Float getCl12shengyuliang() {
        return cl12shengyuliang;
    }

    public void setCl12shengyuliang(Float cl12shengyuliang) {
        this.cl12shengyuliang = cl12shengyuliang;
    }

    public String getCl13mingcheng() {
        return cl13mingcheng;
    }

    public void setCl13mingcheng(String cl13mingcheng) {
        this.cl13mingcheng = cl13mingcheng;
    }

    public Float getCl13shengyuliang() {
        return cl13shengyuliang;
    }

    public void setCl13shengyuliang(Float cl13shengyuliang) {
        this.cl13shengyuliang = cl13shengyuliang;
    }

    public String getCl14mingcheng() {
        return cl14mingcheng;
    }

    public void setCl14mingcheng(String cl14mingcheng) {
        this.cl14mingcheng = cl14mingcheng;
    }

    public Float getCl14shengyuliang() {
        return cl14shengyuliang;
    }

    public void setCl14shengyuliang(Float cl14shengyuliang) {
        this.cl14shengyuliang = cl14shengyuliang;
    }

    public String getCl15mingcheng() {
        return cl15mingcheng;
    }

    public void setCl15mingcheng(String cl15mingcheng) {
        this.cl15mingcheng = cl15mingcheng;
    }

    public Float getCl15shengyuliang() {
        return cl15shengyuliang;
    }

    public void setCl15shengyuliang(Float cl15shengyuliang) {
        this.cl15shengyuliang = cl15shengyuliang;
    }

    public String getCl16mingcheng() {
        return cl16mingcheng;
    }

    public void setCl16mingcheng(String cl16mingcheng) {
        this.cl16mingcheng = cl16mingcheng;
    }

    public Float getCl16shengyuliang() {
        return cl16shengyuliang;
    }

    public void setCl16shengyuliang(Float cl16shengyuliang) {
        this.cl16shengyuliang = cl16shengyuliang;
    }

    public String getCl17mingcheng() {
        return cl17mingcheng;
    }

    public void setCl17mingcheng(String cl17mingcheng) {
        this.cl17mingcheng = cl17mingcheng;
    }

    public Float getCl17shengyuliang() {
        return cl17shengyuliang;
    }

    public void setCl17shengyuliang(Float cl17shengyuliang) {
        this.cl17shengyuliang = cl17shengyuliang;
    }

    public String getCl18mingcheng() {
        return cl18mingcheng;
    }

    public void setCl18mingcheng(String cl18mingcheng) {
        this.cl18mingcheng = cl18mingcheng;
    }

    public Float getCl18shengyuliang() {
        return cl18shengyuliang;
    }

    public void setCl18shengyuliang(Float cl18shengyuliang) {
        this.cl18shengyuliang = cl18shengyuliang;
    }

    public String getCl19mingcheng() {
        return cl19mingcheng;
    }

    public void setCl19mingcheng(String cl19mingcheng) {
        this.cl19mingcheng = cl19mingcheng;
    }

    public Float getCl19shengyuliang() {
        return cl19shengyuliang;
    }

    public void setCl19shengyuliang(Float cl19shengyuliang) {
        this.cl19shengyuliang = cl19shengyuliang;
    }

    public String getCl20mingcheng() {
        return cl20mingcheng;
    }

    public void setCl20mingcheng(String cl20mingcheng) {
        this.cl20mingcheng = cl20mingcheng;
    }

    public Float getCl20shengyuliang() {
        return cl20shengyuliang;
    }

    public void setCl20shengyuliang(Float cl20shengyuliang) {
        this.cl20shengyuliang = cl20shengyuliang;
    }


}
