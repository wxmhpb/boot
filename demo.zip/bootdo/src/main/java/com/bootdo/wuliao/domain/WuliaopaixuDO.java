package com.bootdo.wuliao.domain;

public class WuliaopaixuDO {

    private Integer id;
    private  String  luci;
    private  Integer liaocanghao;
    private   Integer name;
    private  Integer shengyuliang;


//    public String getBeizhu() {
//        return beizhu;
//    }
//
//    public void setBeizhu(String beizhu) {
//        this.beizhu = beizhu;
//    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLuci() {
        return luci;
    }

    public void setLuci(String luci) {
        this.luci = luci;
    }

    public Integer getLiaocanghao() {
        return liaocanghao;
    }

    public void setLiaocanghao(Integer liaocanghao) {
        this.liaocanghao = liaocanghao;
    }

    public Integer getName() {
        return name;
    }

    public void setName(Integer name) {
        this.name = name;
    }

    public Integer getShengyuliang() {
        return shengyuliang;
    }

    public void setShengyuliang(Integer shengyuliang) {
        this.shengyuliang = shengyuliang;
    }

}
