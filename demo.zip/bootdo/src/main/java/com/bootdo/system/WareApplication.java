/*
package com.atguigu.gulimail.ware;

import com.baomidou.mybatisplus.extension.service.IService;
//import com.atguigu.common.utils.PageUtils;
import com.atguigu.gulimail.ware.entity.TbLiaocangyuliangbiaoEntity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Map;

@SpringBootApplication
public class WareApplication {
    public static void main(String[] args) {
        SpringApplication.run(
                WareApplication.class, args);
    }
}
*/
